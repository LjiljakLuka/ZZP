<?php
$upit1="SELECT * FROM User WHERE (DATEDIFF(day,GETDATE()-dateCREATE))<=2";
$upit2="SELECT User.Firstname,User.Lastname, Order.id,Order.value FROM User INNER JOIN Order ON User.id=Order.id";
$upit3="SELECT id , Firstname, Lastname FROM User Group BY Userid having count(Userid)>=2";
$upit4="SELECT User.id, User.Firstname, User.Lastname, Order.id ,Count(id) as [Broj porudzbina] FROM User INNER JOIN Order ON User.id=Order.userid GROUP BY Orderitem.orderid";
$Upit5="SELECT User.id, User.Firstname, User.Lastname, Order.id ,Count(id) as [Broj porudzbina] FROM User INNER JOIN Order ON User.id=Order.userid GROUP BY Orderitem.orderid HAVING count(id)>=2";

?>