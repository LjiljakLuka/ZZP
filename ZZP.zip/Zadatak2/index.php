<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadatak2</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="index.js"></script>
</head>
<body>

    <div id="odgovor" name="odgovor">
    <form id="form" name="formName">
        <h3>Forma za registraciju</h3>
        <div class="form-row">
          <div class="form-group col-md-6 ">
            <label >Ime*</label>
            <input type="text" class="form-control " id="inputIme" name="inputIme" placeholder="Ime" >
            <small style="color: red;"></small>
          </div>
          <div class="form-group col-md-6">
            <label >Prezime*</label>
            <input type="text" class="form-control" id="inputPrezime" name="inputPrezime" placeholder="Prezime" >
          </div>
          <div class="form-group col-md-6">
            <label >Datum Rodjenja*</label>
            <input type="date" class="form-control" id="inputDatum" name="inputDatum" >
          </div>
        </div>
       <legend>Izaberite pol*</legend>
        <div class="form-check" > 
            <input class="form-check-input" type="radio" name="radioPol" id="radioPol" value="Muski" >
            <label class="form-check-label" >
             Muski 
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="radioPol" id="radioPol" value="Zenski">
            <label class="form-check-label" >
             Ženski
            </label>
          </div>
        <div class="form-group col-md-6" >
          <label>Adresa*</label>
          <input type="text" class="form-control" id="inputAdrese" name="inputAdrese" placeholder="Uneti adresu" >
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label >Grad*</label>
            <input type="text" class="form-control" id="inputGrad" name="inputGrad" placeholder="Unesite Grad" >
          </div>
          <div class="form-group col-md-4">
            <label >Država*</label>
            <select id="inputDrzava" name="inputDrzava" class="form-control" >
              <option selected>Izaberite državu*</option>
              <option value="Srbija">Srbija</option>
              <option value="Makedonija">Makedonija</option>
              <option value="BiH">Bih</option>
            </select>
          </div>
        </div>
        <div class="form-group col-md-4">
          <label >Example textarea*</label>
          <textarea class="form-control" id="inputTextarea" name="inputTextarea" rows="3" ></textarea>
        </div>
       <div class="form-group">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="gridCheck" >
          <label class="form-check-label" >
            Slažem se sa uslovima korišćenja
          </label>
        </div>
      </div>
      
         <button type="submit" name="posalji" id="posalji" onclick="proveri()" class="btn btn-primary" >Pošalji</button> 
      </form>
    </div>
</body>
</html>