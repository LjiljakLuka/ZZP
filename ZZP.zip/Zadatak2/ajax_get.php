<?php
$ime=$_GET['ime'];
$prezime=$_GET['prezime'];
$datum=$_GET['datum'];
$pol=$_GET['pol'];
$adresa=$_GET['adresa'];
$grad=$_GET['grad'];
$drzava=$_GET['drzava'];
$textArea=$_GET['textArea'];

echo" Uneti podaci su:<br>Ime:".$ime."<br>Prezime: ".$prezime."<br>Pol: ".$pol."<br>Datum: ".$datum."<br>Adresa: ".$adresa."<br>Grad: ".$grad." <br>Država:".$drzava." <br>textArea:".$textArea;
?>