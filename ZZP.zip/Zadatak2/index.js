$(document).ready(function () {
    $("#posalji").click(function (e) {
        e.preventDefault()
        console.log("asdasdasd");
        const unosIme=$("#inputIme").val().trim();
        const unosPrezime=$("#inputPrezime").val().trim();
        const unosDatum=$("#inputDatum").val();
        const unosPol=$("#radioPol").val();
        const unosAdrese=$("#inputAdrese").val().trim();
        const unosGrad=$("#inputGrad").val().trim();
        const unosDrzava=$("#inputDrzava").val();
        const unosTextarea=$("#inputTextarea").val().trim();
       

        
        if (unosIme==="" || unosPrezime==="" || unosDatum==="" || unosPol==="" || unosAdrese==="" || unosGrad===""  || unosDrzava==="" || unosTextarea==="") {
        alert("svi podaci su obavezni");
            return;
        }
        else if ($("#gridCheck").prop('checked') == false) {
            alert("Prihvatite uslove koriscenja");
            return;
        }
         
        $.get("ajax_get.php", {ime: unosIme, prezime: unosPrezime, datum: unosDatum, pol: unosPol, adresa: unosAdrese, grad: unosGrad, drzava: unosDrzava, textArea: unosTextarea}, function(response){
            $("#odgovor").html(response);
        })
    })
})


